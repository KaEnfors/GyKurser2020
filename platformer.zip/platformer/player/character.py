from core import PhysicsSprite


class Character(PhysicsSprite):
    pass

#    def on_update(self, delta):
#        pass    




